clear all; close all; clc
%function Keff=CondutividadeTermicaEfetivaCross3D(PHI,SIGMA,DIRECTION,level)
PHI=0.2;
SIGMA=100;
DIRECTION=1;
tic
Nnl=4;
filename=['bi_08_h_1.vol']
[x,y,z,surfnr_BOOL,IEN,nel,Srf,nnp]=MyVolLoader3d(filename);
[Vc,Vd]=calcPHI3d(x,y,z,IEN,nel,surfnr_BOOL); %calcula o volume ocupado pelo material c e o d e verifica o tamanho dos elementos
[val,idx]=min(abs([Vc,Vd]-PHI));
    if idx == 1
        surfnr_BOOL=~surfnr_BOOL;
        [Vc,Vd]=calcPHI3d(x,y,z,IEN,nel,surfnr_BOOL); %calcula o volume ocupado pelo material c e o d e verifica o tamanho dos elementos
    end
%plotmesh3d
PARES=ParesCorrespondentes_linear(x,y,z,nnp);
[PARES,ndof]=quinas(x,y,z,PARES,nnp);
ReorganizarPares
MontagemMatrizLM
DIRECTION=['F' num2str(DIRECTION)];
for e=1:nel
    [k,f]=ElLinear(x,y,z,IEN,e,surfnr_BOOL,SIGMA,DIRECTION);
    AssembleLinear;
end
chi=GC_red_precondicionado(F,K_red,LM,nel);
for e=1:nel
    Condutividade(e)=SomatorioKElLinear(x,y,z,IEN,LM,e,chi,surfnr_BOOL,SIGMA,DIRECTION);
end
K=sum(Condutividade);
Keff=[K, Vd, Vc, toc]
K
toc

