function VALUE=DELTA(a,b)
a=floor(a);b=floor(b);
if a==b
    VALUE=1;
else
    VALUE=0;
end
    